<? include "ippristup.php"; ?> 

<HTML>

<center>


Smazani akce<br><br>


 <? 


$soubor= $den."i".$mesic."i".$rok.".txt";

if (File_Exists($soubor))  
{

include $soubor;
$nakase= ($cena1*$prodano1+$cena2*$prodano2+$cena3*$prodano3+$cena4*$prodano4)-$zuctovano;




if ($informace>0)
{
print "<font color=red>Akce kterou chcete smazat obsahuje penize na kase - nejprve je nutn� pen�ze vybrat!
</font><P><A href=tm.php?heslo=".$heslo."&mesic=".$mesic."> zpet</A>";
exit;
}

unlink($soubor);
print "Akce byla smazana...
<P><A href=tm.php?heslo=".$heslo."&mesic=".$mesic."> Zpet</A>";}


else
{
print "<font color=red>V tento den akce neexistuje!
</font><P><A href=tm.php?heslo=".$heslo."&mesic=".$mesic."> Zpet</A>";
exit;
 
}


?>