<? include "ippristup.php"; ?> 

<HTML>
<left>
<Head>
<left>
<style media="print">
.tlac {
display:none;
}
.txt1 {
display:none;
}


</style>
</Head>
<p align=left>




<?



$soubor= $den."i".$mesic."i".$rok.".txt";
include "$soubor";

$soubor2= "prodano".$soubor;
if (File_Exists($soubor2))  {  
include "$soubor2";
print "$prodano";
} 


if ($rok < 10){ $rok1= "0".$rok ;}

print "<table width='800' >";


while ($pocitadlo1 <= $kolik-1 ){ 
$pocitadlo1 = $pocitadlo1 + 1;
$celkem =$prodano1+$prodano2+$prodano3+$prodano4+$pocitadlo1;


if ($pocitadlo1 <= 4){
$vejska =262;
}
else
{
$vejska =1;
}
if ($vyber ==  0){$cenalistku=$cena1;}
if ($vyber ==  1){$cenalistku=$cena2;}
if ($vyber ==  2){$cenalistku=$cena3;}
if ($vyber ==  3){$cenalistku=$cena4;}


print "<BR><BR><BR><BR><tr><td width='800'><table bgcolor=white border=0 cellpadding=0 width='700' align=left>";

print "<tr>";
print "<td height=1 width='450' valign=top ></td>";
print "<td height=$vejska width='350' valign=top >";
print "<font size=5 color=black><B><font color=black>".$akce."<BR></H1>";
print "<td width='100' valign=top align=center>";
print "<font size=5 color=black ><B><i>".$den.".".$mesic.".".$rok1."<BR>";
print "</td>";
print "<td width='100' valign=top>";
print "<font size=5 color=black><B><i>".$zacatek."<BR>";
print "</td>";

print "<td width='150' valign=top >";
print "<font size=5 color=black><B><i>".$cenalistku.",-";
print "</td>";

print "<td width='150' valign=top >";
print "<font size=5 color=black><B><i>".$celkem;
print "</td></tr>";
print "</table>";


if ($pocitadlo1 <= 5){
print "";
}
} 
print "</td></tr></table>";



if ($vyber ==  0){$prodej1=$kolik+$prodano1;$prodej2=$prodano2;$prodej3=$prodano3;$prodej4=$prodano4;$info= $cena1*$kolik+$informace;}
if ($vyber ==  1){$prodej2=$kolik+$prodano2;$prodej1=$prodano1;$prodej3=$prodano3;$prodej4=$prodano4;$info= $cena2*$kolik+$informace;}
if ($vyber ==  2){$prodej3=$kolik+$prodano3;$prodej1=$prodano1;$prodej2=$prodano2;$prodej4=$prodano4;$info= $cena3*$kolik+$informace;}
if ($vyber ==  3){$prodej4=$kolik+$prodano4;$prodej1=$prodano1;$prodej2=$prodano2;$prodej3=$prodano3;$info= $cena4*$kolik+$informace;}


$zapis2 = fopen($den."i".$mesic."i".$rok.".txt","w+");


$prodanolist1 = "<? $"."prodano1=$prodej1 ;?>";
$prodanolist2 = "<? $"."prodano2=$prodej2 ;?>";
$prodanolist3 = "<? $"."prodano3=$prodej3 ;?>";
$prodanolist4 = "<? $"."prodano4=$prodej4 ;$"."zuctovano=$zuctovano ;?>";





$prachycelk = "$"."cena1=".$cena1.";$"."cena2=".$cena2.";$"."cena3=".$cena3.";$"."cena4=".$cena4;






$listek = $prodanolist1.$prodanolist2.$prodanolist3.$prodanolist4."<? $"."akce='" .$akce ."';".$prachycelk.";$"."den=".$den.";$"."mesic=".$mesic.";$"."rok=".$rok."; $"."bloktisk=0; $"."maximum=" .$maximum ."; $"."informace=" .$info ."; $"."zacatek='" .$zacatek ."' ?>";


fwrite($zapis2,$listek);
fclose($zapis2);
?>

<script>
window.onload = fff

function fff(){
window.print();
<? print "window.location.href='tm.php?heslo=".$heslo."&m=".$mesic."'; ";?>
}
</script>



</HTML>

