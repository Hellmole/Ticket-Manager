<style media="print">
.odkaz {
display:none;
}
</style>


<? include "ippristup.php"; ?> 

<center>
<?php 
$den=0;

while ($den <= 31 )
{ 

$soubor= $den."i".$mesic."i".$rok.".txt";
if (File_Exists($soubor))  {  
include "$soubor";

///$zuc-neplati= ($cena1*$prodano1+$cena2*$prodano2+$cena3*$prodano3+$cena4*$prodano4)-$zuctovano;

$zapis2 = fopen("$soubor","w+");



///$zuc1-nepati=$zuc+$zuctovano;

$zuc1=$informace+$zuctovano;
$informace=0;

$prodanolist1 = "<? $"."prodano1=$prodano1 ;?>";
$prodanolist2 = "<? $"."prodano2=$prodano2 ;?>";
$prodanolist3 = "<? $"."prodano3=$prodano3 ;?>";
$prodanolist4 = "<? $"."prodano4=$prodano4 ;$"."zuctovano=$zuc1 ;?>";




$prachycelk = "$"."cena1=".$cena1.";$"."cena2=".$cena2.";$"."cena3=".$cena3.";$"."cena4=".$cena4;






$listek = $prodanolist1.$prodanolist2.$prodanolist3.$prodanolist4."<? $"."akce='" .$akce ."';".$prachycelk.";$"."den=".$den.";$"."mesic=".$mesic.";$"."rok=".$rok."; $"."bloktisk=".$bloktisk."; $"."maximum=" .$maximum ."; $"."informace=" .$informace ."; $"."zacatek='" .$zacatek ."' ?>";


fwrite($zapis2,$listek);
fclose($zapis2);

$cas = Date("j/m/Y H:i:s", Time());
$databaze = 2000 + $rok;
$historie = fopen("historie/".$databaze.".htm","a+");
$his = $cas."|<b> vybrano: ".$zuc.",- </b>/".$celk.",- |".$den.".".$mesic.".".$rok."-".$akce."<br>";
fwrite($historie,$his);
fclose($historie);

}
$den=$den+1;
}
$his2 = $cas."|<b> vybrano: ".$celk.",-</b> |- za vsechny akce v mesici <br>";
print "$his2";
?>
<p>Castka byla vydana z kasy...<p>
penize prevzal................... penize vydal......................<p>

<? print "<P><A class=odkaz href=tm.php?heslo=".$heslo."&m=".$mesic."> zpet</A>/";?>
<A class=odkaz href="javascript:window.print()"> tisk</A>