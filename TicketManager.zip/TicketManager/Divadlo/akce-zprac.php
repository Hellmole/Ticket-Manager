<? include "ippristup.php"; ?> 

<HTML>

<center>


Pridani akce<br><br>

<? 
if ((!$nazev) || (!$prachy1) || (!$max)  || (!$od))
{
print "<font color=red>Mus� b�t vypln�ny v�echny �daje!!!
</font><P><A href=tm.php?heslo=".$heslo."&mesic=".$mesic."> Zpet</A>";
} 
else{
 

$r = (int)$r;
$d = (int)$d;
$m = (int)$m;
$prachy44 = (int)$prachy4;
$prachy33 = (int)$prachy3;
$prachy22 = (int)$prachy2;
$prachy11 = (int)$prachy1;

$prachycelk = "$"."cena1=".$prachy11.";$"."cena2=".$prachy22.";$"."cena3=".$prachy33.";$"."cena4=".$prachy44;



$presmerovani="nazev=".$nazev."&prachy=".$prachy33."&d=".$d."&m=".$m."&r=".$r."&max=".$max."&od=".$od."&akce=".$akce."&heslo=".$heslo;
$soubor= $d."i".$m."i".$r.".txt";

if (File_Exists($soubor))  {
print "V Tento den jiz akce existuje!
<P><A href=prepsat-zprac.php?".$presmerovani."> Prepsat</A>/
<A href=tm.php?heslo=".$heslo."&mesic=".$mesic."> Zpet</A>";
exit;
}


$prodanolist1 = "<? $"."prodano1=0 ;?>";
$prodanolist2 = "<? $"."prodano2=0 ;?>";
$prodanolist3 = "<? $"."prodano3=0 ;?>";
$prodanolist4 = "<? $"."prodano4=0 ;$"."zuctovano=0 ;?>";




$zapis = fopen($soubor,"w+");
$listek = $prodanolist1.$prodanolist2.$prodanolist3.$prodanolist4."<? $"."akce='" .$nazev ."';".$prachycelk.";$"."den=".$d.";$"."mesic=".$m.";$"."rok=".$r."; $"."bloktisk=0; $"."maximum=" .$max ."; $"."informace=0; $"."zacatek='" .$od ."' ?>";

fwrite($zapis,$listek);
fclose($zapis);


///print "dd:".$d1;
print "Akce byla zapsana...
<A href=tm.php?heslo=".$heslo."&mesic=".$mesic."> Zpet</A>";
} 
?>




