<? include "ippristup.php"; ?> 

<center>
<?php
print "Opravdu chcete akci smazat???";
print "<A href=smaz-zprac.php?zuc=".$zuc."&heslo=".$heslo."&mesic=".$mesic."&rok=".$rok."&den=".$den.">ANO</A>/";
print "<A href=tm.php?heslo=".$heslo."&mesic=".$mesic.">NE</A>"; 
?>
