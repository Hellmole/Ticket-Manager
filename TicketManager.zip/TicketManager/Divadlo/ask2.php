<? include "ippristup.php"; ?> 

<center>
<?php
print "Opravdu chcete odebrat z kasy castku: ".$zuc.",-<P>";
print "<A href=vyplatit.php?zuc=".$zuc."&heslo=".$heslo."&mesic=".$mesic."&rok=".$rok."&den=".$den.">ANO</A>/";
print "<A href=tm.php?heslo=".$heslo."&mesic=".$mesic.">NE</A>"; 
?>
