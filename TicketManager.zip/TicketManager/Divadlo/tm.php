<style>
a:active {text-decoration: none;
}

.tab1 {
border-color: steelblue; 
border-style: solid; 
border-width: 1 1 1 1; 
width: 700px;
font-size : 12px;
color : black;
font-family : Verdana, Geneva, Arial, Helvetica, sans-serif;
padding:20px;
background-color: none;
}


.tab2 {
border-color: steelblue; 
border-style: solid; 
border-width: 1 1 1 1; 
font-size : 12px;
color : black;
font-family : Verdana, Geneva, Arial, Helvetica, sans-serif;
background-color: none;
}
.tab3 {
border-color: steelblue; 
border-style: solid; 
border-width: 1 1 1 1; 
height: 30;


font-size : 12px;
color : black;
font-family : Verdana, Geneva, Arial, Helvetica, sans-serif;
background-color: orange;
}
.odkaz {
border-color: steelblue; 
border-style: solid; 
border-width: 1 1 1 1; 
font-size : 12px;
color : black;
font-family : Verdana, Geneva, Arial, Helvetica, sans-serif;
background-color: gold;
text-decoration: underline;
}

.odkaz2 {
border-color: steelblue; 
border-style: solid; 
border-width: 1 1 1 1; 
font-size : 12px;
color : red;
font-family : Verdana, Geneva, Arial, Helvetica, sans-serif;
background-color: gold;
text-decoration: underline;
}



</style>


<? include "ippristup.php"; ?> 

<center>
<body bgcolor=white><body>

<?php 
$h = 1596; /// heslo
$den = 1;

/// aktualni datum

$ak = Date("d/m"); 
$ak2 = Date("m"); 
if ($rok=="") {$rok1 = Date("Y"); $rok = $rok1-2000;} 
if ($mesic==""){ $mesic1 = Date("m"); $mesic = (int)$mesic1;}

///

/// podminky listovani rok/mesic

$mesic=$mesic+$mesicposun;
$rok=$rok+$rokposun;
if ($mesic >= 12){
$mesic=12;
}
if ($mesic <= 1){
$mesic=1;
}

// spocitani dnu pro kalendar

// prestupnak
$prest=$rok;
while (2 <= $prest) 
{ 
$prest= $prest/2;
}

///

$pocetdnu=31;

///


/// prehozovani ruku a mesice

$odkaz1 = "rok=".$rok."&mesic=".$mesic."&heslo=".$heslo;
print "Rok<BR>";
print "<A class=odkaz href=tm.php?rokposun=-1&".$odkaz1."> &lt;&nbsp</A>";
print $rok+2000;
print "<A class=odkaz href=tm.php?rokposun=1&".$odkaz1.">&gt;</A><BR>";
print "<BR><table class=tab1 bgcolor=beige>";
print "<tr><td class=tab3 align=center >";
print "Mesic ";
print "<A class=odkaz href=tm.php?mesicposun=-1&".$odkaz1."> &lt;&nbsp</A>";
print $mesic;
print "<A class=odkaz href=tm.php?mesicposun=1&".$odkaz1.">&gt;</A>";

////

/// vykresleni tlacitek pridat akci, prej, smaz

print "<td align=center class=tab3 >
<A class=odkaz href=http://www.hodnemuziky.cz/koncerty/tm.php?heslo=".$heslo."&mesic=".$ak2.">Koncerty
<A class=odkaz href=http://www.hodnemuziky.cz/divadlo/tm.php?heslo=".$heslo."&mesic=".$ak2.">/<font size=13>Divadlo</font>";


print "&nbsp;<td align=center class=tab3>Na kase";
print "<td align=center class=tab3 > Funkce";

/// vypsani kalendare s odkazy
while ($den <= $pocetdnu )
{ 
$odkaz1 = "rok=".$rok."&mesic=".$mesic."&heslo=".$heslo."&den=".$den;
$soubor= $den."i".$mesic."i".$rok.".txt";
if (File_Exists($soubor))  {  
print "<tr><td align=center valign=top class=tab2>
<A class=odkaz href=nahled.php?".$odkaz1.">".$den.".".$mesic.".</A>";
include "$soubor";

/// $vyplatit-neplati= ($cena1*$prodano1+$cena2*$prodano2+$cena3*$prodano3+$cena4*$prodano4)-$zuctovano;
$pole[] = $informace;


print "<td align=center valign=top class=tab2> - $akce";

print "<td align=center valign=top class=tab2>".$informace.",-" ;



if ($bloktisk==0){
print "<td align=center valign=top class=tab2 width=250>
<A class=odkaz href=tisk1.php?".$odkaz1."&vyber=0> Tisk: $cena1,-/</A>
<A class=odkaz2 href=tisk1.php?".$odkaz1."&vyber=1> $cena2,-/</A>
<A class=odkaz2 href=tisk1.php?".$odkaz1."&vyber=2> $cena3,-/</A>
<A class=odkaz2 href=tisk1.php?".$odkaz1."&vyber=3> $cena4,-</A>";


if ($heslo==$h){
print "<A class=odkaz href=zrusit-obnovit.php?".$odkaz1."><br> Zastavit </A>";


}
}
else{
if ($heslo==$h){
print "<td align=center class=tab2><A class=odkaz href=zrusit-obnovit.php?".$odkaz1."> Obnovit </A>";
}
}
}

else{
print "<tr><td align=center valign=top><font color=gray>".$den.".".$mesic;

if ($heslo==$h){
print "<td><A class=odkaz href=akce1.php?".$odkaz1."&funkce=1> Zapsat</A>";
}

}





$den=$den+1;
print "<br>";



}

while ($secist <= $pocetdnu ){
$celk = $pole[$secist-1]+$celk;
$secist=$secist+1;
}
print "<tr><td>&nbsp;";
print "<tr><td align=center>";
print "<A class=odkaz href=tm.php?heslo=".$heslo."&mesic=".$ak2." >". $ak."</A>";
print "<td align=center ><font color=black> Celkem za mesic: <b> ".$celk." ,-</b> ";

if ($heslo==$h){
print "<td width=90><A class=odkaz href=ask1.php?".$odkaz1."&celk=".$celk.">Zuc. mesic!<br><td></A>";
$his=2000+$rok;
print "<A class=odkaz href=historie/".$his.".htm target=_blank >Zobrazit Historii</A>";
}

print "</table>";

?>
