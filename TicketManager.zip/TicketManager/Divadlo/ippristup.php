<?
print "<center>";
$ip = $_SERVER['REMOTE_ADDR'];
$ip1 = "xxx.xxx.xxx.xxx";
$ip2 = "xxx.xxx.xxx.xxx";
$ip3 = "xxx.xxx.xxx.xxx";
$ip4 = "xxx.xxx.xxx.xxx";
$ip6 = "xxx.xxx.xxx.xxx";
$ip7 = "xxx.xxx.xxx.xxx";
$ip8 = "xxx.xxx.xxx.xxx";
$ip9 = "xxx.xxx.xxx.xxx";
$ip10 = "xxx.xxx.xxx.xxx";
$ip11 = "xxx.xxx.xxx.xxx";

if ($ip1 != $ip and $ip2 != $ip and $ip3 != $ip and $ip4 != $ip and $ip5 != $ip and $ip6 != $ip and $ip7 != $ip and $ip8 != $ip  and $ip9 != $ip  and $ip10 != $ip  and $ip11 != $ip) {
print $ip. "- neznama adresa! <p>" ;
echo "Pristup byl odepren!!!";
exit;
}
?>

