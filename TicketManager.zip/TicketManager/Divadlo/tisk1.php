<? include "ippristup.php"; ?> 

<HTML>
<Head>

</Head>


<BODY BGCOLOR=white  vlink = #006699 link= #006699 text=black>
<center>


<H3>
Kolik vytisknout listku?<BR><BR></H3>
<? 
$soubor= $den."i".$mesic."i".$rok.".txt";

if (File_Exists($soubor))  
{ include "$soubor";} 

if (($prodano1 +$prodano2+$prodano3 +$prodano4) >= $maximum) { print "Prekrocen maximalni pocet mist..."; }


$mesic1 = Date("m"); $mesicakt = (int)$mesic1;
$den1 = Date("d"); $denakt = (int)$den1;
$rok1 = Date("y"); $rokakt = (int)$rok1;



/// if ($mesic = $mesicakt and $den < $denakt and $rok = $rokakt) { 
/// print "Vyprsel cas predprodeje..."; 


/// $blok=1;
// }

while ($pocitadlo <= 4)
{
$pocitadlo=$pocitadlo+1;
if (($prodano1+$prodano2+$prodano3+$prodano4) <= $maximum-$pocitadlo and $blok==0)
{
print "<A href=listek.php?kolik=".$pocitadlo."&mesic=".$mesic."&den=".$den."&rok=".$rok."&vyber=".$vyber."&heslo=".$heslo.">".$pocitadlo."</A>&nbsp/&nbsp";
}

}



?>
<P>

<? print "<A href=tm.php?heslo=".$heslo."&mesic=".$mesic."> Zpet</A>"; ?>



</HTML>
