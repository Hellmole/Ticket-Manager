<? include "ippristup.php"; ?> 

<HTML>

<BODY BGCOLOR=white  vlink = #006699 link= #006699 text=black>
<left>


<style media="print">
.tlac {
display:none;
}
.txt1 {
display:none;
}

</style>
</Head>
<center>




<?
$soubor= $den."i".$mesic."i".$rok.".txt";
if (File_Exists($soubor))  {  
include "$soubor";
}
?>
<H2>Akce</H2>

*** Rock Caf� (Nov� horizont spol. s r.o.)<BR>
N�rodn� 20, 110 00 Praha 1<BR>
Tel., fax: 224 933 947<BR><BR>
-------------------------------------------------<BR>

<table >
<tr><td>Akce: </td><td><? echo $akce;  ?></td><tr/>
<tr><td>Datum akce: </td><td><? echo $den."/".$mesic."/".$rok." - ".$zacatek; ?></td><tr/>
<tr><td>Maxim�ln� po�et m�st: </td><td><? echo $maximum; ?></td><tr/>

<tr><td>aktu�ln� cena 1 za kus: </td><td><? echo $cena1.",-"; ?></td><tr/>
<tr><td>aktu�ln� cena 2 za kus:</td><td><? echo $cena2.",-"; ?></td><tr/>
<tr><td>aktu�ln� cena 3 za kus:</td><td><? echo $cena3.",-"; ?></td><tr/>
<tr><td>aktu�ln� cena 4 za kus: </td><td><? echo $cena4.",-"; ?></td><tr/>


<tr><td>prodano mist (cena1/cena2/cena3/cena4): </td><td><? echo $prodano1."/".$prodano2."/".$prodano3."/".$prodano4."/"; ?></td><tr/>
<tr><td>prodano mist celkem: </td><td><? echo $prodano1+$prodano2+$prodano3+$prodano4; ?></td><tr/>
<tr><td>celkem penez za akci: </td><td><? echo $informace+$zuctovano.",-"; ?></td><tr/>



<tr><td>aktu�ln� v kase: </td><td><b><? echo $informace; ?>,-</b></td><tr/>

<tr><td>Odebr�no v pr�b�hu prodeje: </td><td><? echo $zuctovano; ?>,-</td><tr/>
</table><br><br>

<?
if ($heslo==1596){
$odkaz1 = "rok=".$rok."&mesic=".$mesic."&heslo=".$heslo."&den=".$den."&mesic=".$mesic."&zuc=".$informace;







print "<A href=ask2.php?".$odkaz1.">Zuctovat</A>/";

print "<A href=akce1.php?".$odkaz1."&funkce=3>Zmenit �daje o akci</A>/";

print "<A href=ask3.php?".$odkaz1."&funkce=4>Smazat</A>/";


}
print "<A href=tm.php?heslo=".$heslo."&mesic=".$mesic."> Zpet</A>"; ?>






</HTML>

