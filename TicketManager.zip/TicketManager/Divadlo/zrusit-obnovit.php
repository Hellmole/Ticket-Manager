<? include "ippristup.php"; ?> 

<center>
<?
$soubor= $den."i".$mesic."i".$rok.".txt";
if (File_Exists($soubor))  {  
include "$soubor";} 
$zapis2 = fopen("$soubor","w+");


if ($bloktisk == 1)  { $bloktisk = 0;$hlaska = obnoven;}
else { $bloktisk = 1;$hlaska = zrusen;}

$prodanolist1 = "<? $"."prodano1=$prodano1 ;?>";
$prodanolist2 = "<? $"."prodano2=$prodano2 ;?>";
$prodanolist3 = "<? $"."prodano3=$prodano3 ;?>";
$prodanolist4 = "<? $"."prodano4=$prodano4 ;$"."zuctovano=$zuctovano;?>";

$prachycelk = "$"."cena1=".$cena1.";$"."cena2=".$cena2.";$"."cena3=".$cena3.";$"."cena4=".$cena4;






$listek = $prodanolist1.$prodanolist2.$prodanolist3.$prodanolist4."<? $"."akce='" .$akce ."';".$prachycelk.";$"."den=".$den.";$"."mesic=".$mesic.";$"."rok=".$rok."; $"."bloktisk=".$bloktisk."; $"."maximum=" .$maximum ."; $"."informace=" .$informace ."; $"."zacatek='" .$zacatek ."' ?>";


fwrite($zapis2,$listek);
fclose($zapis2);




echo "Predprodej byl $hlaska...";

?>

<? print "<P><A href=tm.php?heslo=".$heslo."&m=".$mesic."> zpet</A>"; ?>