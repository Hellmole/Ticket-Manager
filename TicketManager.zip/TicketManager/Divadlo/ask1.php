<? include "ippristup.php"; ?> 

<center>
<?php
print "Opravdu chcete odebrat z kasy castku: ".$celk.",-<br>";
print "<br><A href=zuc-mesic.php?heslo=".$heslo."&mesic=".$mesic."&rok=".$rok."&celk=".$celk."> ANO</A>/";
print "<A href=tm.php?heslo=".$heslo."&mesic=".$mesic."> NE</A>";

?>