<style media="print">
.odkaz {
display:none;
}



</style>
<? include "ippristup.php"; ?> 
<center>
<?
$soubor= $den."i".$mesic."i".$rok.".txt";
if (File_Exists($soubor))  {  
include "$soubor";} 
$zapis2 = fopen("$soubor","w+");

///$zuc-neplati= ($cena1*$prodano1+$cena2*$prodano2+$cena3*$prodano3+$cena4*$prodano4)-$zuctovano; 


$informace=0;

$prodanolist1 = "<? $"."prodano1=$prodano1 ;?>";
$prodanolist2 = "<? $"."prodano2=$prodano2 ;?>";
$prodanolist3 = "<? $"."prodano3=$prodano3 ;?>";
$prodanolist4 = "<? $"."prodano4=$prodano4 ;$"."zuctovano=$zuctovano+$zuc;?>";

$prachycelk = "$"."cena1=".$cena1.";$"."cena2=".$cena2.";$"."cena3=".$cena3.";$"."cena4=".$cena4;






$listek = $prodanolist1.$prodanolist2.$prodanolist3.$prodanolist4."<? $"."akce='" .$akce ."';".$prachycelk.";$"."den=".$den.";$"."mesic=".$mesic.";$"."rok=".$rok."; $"."bloktisk=".$bloktisk."; $"."maximum=" .$maximum ."; $"."informace=" .$informace ."; $"."zacatek='" .$zacatek ."' ?>";


fwrite($zapis2,$listek);
fclose($zapis2);



/// zaznamenani
$cas = Date("j/m/Y H:i:s", Time());
$databaze = 2000 + $rok;
$historie = fopen( "historie/".$databaze.".htm","a+");
$his = $cas." | <b>castka: ".$zuc.",-</b>  |".$den.".".$mesic.".".$rok."-".$akce."<br>";
fwrite($historie,$his);
fclose($historie);
print "$his";
?>
<p>Castka byla vydana z kasy...<p>
penize prevzal................... penize vydal......................<p>

<? print "<P><A class=odkaz href=tm.php?heslo=".$heslo."&m=".$mesic."> zpet</A>/";?>
<A class=odkaz href="javascript:window.print()"> tisk</A>