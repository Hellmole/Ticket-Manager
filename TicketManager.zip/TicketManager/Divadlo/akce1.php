<? include "ippristup.php"; ?> 

<HTML>

<center>



<?php 
$odkaz1 = "r=".$rok."&m=".$mesic."&heslo=".$heslo."&d=".$den."&mesic=".$mesic;


if ($funkce==1){
print "<b><H3>Pridani nove akce</H3><p>* povinn� �daje<p></b>";
print "<FORM ACTION=akce-zprac.php?".$odkaz1." METHOD=post ENCTYPE=multipart/form-data>";
}
if ($funkce==3) {
print "<b><H3>Zm�na �daj� o akci<p></H3></b>- Zde m��ete m�nit �daje...<p>";
print "<FORM ACTION=prejm-zprac.php?".$odkaz1." METHOD=post ENCTYPE=multipart/form-data>";
$soubor= $den."i".$mesic."i".$rok.".txt";
include "$soubor";

}
if ($funkce==4) {
print "<b>Smazani akce<p></b>";
print "<FORM ACTION=smaz-zprac.php?".$odkaz1." METHOD=post ENCTYPE=multipart/form-data>";
}
if ($funkce==5) {
print "<b>Zmena cen<p></b>";
print "<FORM ACTION=zmenacen-zprac.php?".$odkaz1." METHOD=post ENCTYPE=multipart/form-data>";

}
?>



<?
if ($funkce < 4) {
print "* Nazev akce (napr.: Sepultura):<BR>
<input type='text' value='$akce' name='nazev' size='30'><BR><BR>
* Max. pocet listku (napr.: 250):<BR>
<input type='text' value='$maximum' name='max' size='10'><BR><BR>
* Zacatek akce (napr.: 21:00):<BR>
<input type='text' value='$zacatek' name='od' size='10'><BR><BR>";
}

if ($funkce < 3 or $funkce=5) {
print "* Cena1 (napr.: 130):<BR>
<input type='text' value='$cena1' name='prachy1' size='10'> ,-<BR><BR>";

print "Cena2 (napr.: 89):<BR>
<input type='text' value='$cena2' name='prachy2' size='10'> ,-<BR><BR>";

print "Cena3 (napr.: 109):<BR>
<input type='text' value='$cena3' name='prachy3' size='10'> ,-<BR><BR>";

print "Cena4 (napr.: 1):<BR>
<input type='text' value='$cena4' name='prachy4' size='10'> ,-<BR><BR>";







}







?>
<INPUT TYPE='submit' NAME='akce' VALUE='Proved!'>


</FORM>
<? print "<A href=tm.php?heslo=".$heslo."&mesic=".$mesic."> Zpet</A>";


