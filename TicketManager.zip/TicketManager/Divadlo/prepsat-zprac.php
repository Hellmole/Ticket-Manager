<? include "ippristup.php"; ?> 

<HTML>

<center>


Pridani akce<br><br>

<? 
if ((!$nazev) || (!$prachy)  || (!$d)  || (!$m)  || (!$r)  || (!$max)  || (!$od))
{
print "<font color=red>Mus� b�t vypln�ny v�echny �daje!!!";
} 
else{
 

$r = (int)$r;
$d = (int)$d;
$m = (int)$m;


$soubor= $d."i".$m."i".$r.".txt";

if (File_Exists($soubor))  {
include $soubor;
$vyplatit= $cena*$prodano-$zuctovano;
if ($vyplatit>0) {
print "<font color=red>Akce kterou chcete prepsat obsahuje penize na kase!
</font><P><A href=tm.php?heslo=".$heslo."&mesic=".$mesic."> zpet</A>";
exit;
}
}

$prodanolist = "<? $"."prodano=0 ;$"."zuctovano=0 ;?>";
$zapis = fopen($soubor,"w+");
$listek = $prodanolist."<? $"."akce='" .$nazev ."';$"."cena=" .$prachy .";$"."den=" .$d.";$"."mesic=" .$m.";$"."rok=" .$r."; $"."bloktisk=0; $"."maximum=" .$max ."; $"."informace=" .$informace ."; $"."zacatek='" .$od ."' ?>";

fwrite($zapis,$listek);
fclose($zapis);



print "Akce byla zapsana...";

} 
print "<P><A href=tm.php?heslo=".$heslo."&mesic=".$mesic."> zpet</A>";
?>




