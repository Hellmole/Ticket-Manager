<? include "ippristup.php"; ?> 

<HTML>

<center>


Prihlaseni<br><br>

<FORM ACTION="tm.php" METHOD="post" ENCTYPE="multipart/form-data">

<b>Heslo:
<input type="password" name="heslo" size="30"><BR><BR>
<INPUT TYPE="submit" NAME="akce" VALUE="Prihlasit">
</FORM>

<a href="tm.php" onclick="window.open('tm.php','okno','menubar=yes,top=10'); return false">Bez prihlaseni</a>

