<? include "ippristup.php"; ?> 

<HTML>

<center>


Prejmenovani akce<br><br>

<? 
if ((!$nazev) || (!$d)  || (!$m)  || (!$r)  || (!$max)  || (!$od))
{
print "<font color=red>Mus� b�t vypln�ny v�echny �daje!!!
</font><P><A href=tm.php?heslo=".$heslo."&mesic=".$mesic."> Zpet</A>";
} 
else{
 

$r = (int)$r;
$d = (int)$d;
$m = (int)$m;


$soubor= $d."i".$m."i".$r.".txt";

if (File_Exists($soubor))  {
include $soubor;


$prachy44 = (int)$prachy4;
$prachy33 = (int)$prachy3;
$prachy22 = (int)$prachy2;
$prachy11 = (int)$prachy1;

$prodanolist1 = "<? $"."prodano1=$prodano1 ;?>";
$prodanolist2 = "<? $"."prodano2=$prodano2 ;?>";
$prodanolist3 = "<? $"."prodano3=$prodano3 ;?>";
$prodanolist4 = "<? $"."prodano4=$prodano4 ;$"."zuctovano=$zuctovano ;?>";



if ($prachy44==0){$prachy44=$cena4;}
if ($prachy33==0){$prachy33=$cena3;}
if ($prachy22==0){$prachy22=$cena2;}
if ($prachy11==0){$prachy11=$cena1;}

$prachycelk = "$"."cena1=".$prachy11.";$"."cena2=".$prachy22.";$"."cena3=".$prachy33.";$"."cena4=".$prachy44;






$zapis = fopen($soubor,"w+");



$listek = $prodanolist1.$prodanolist2.$prodanolist3.$prodanolist4."<? $"."akce='" .$nazev ."';".$prachycelk.";$"."den=".$d.";$"."mesic=".$m.";$"."rok=".$r."; $"."bloktisk=0; $"."maximum=" .$max ."; $"."informace=" .$informace ."; $"."zacatek='" .$od ."' ?>";





fwrite($zapis,$listek);
fclose($zapis);

print "Akce byla prejmenovana...
<P><A href=tm.php?heslo=".$heslo."&mesic=".$mesic."> Zpet</A>";
}
else
{
print "<font color=red>V tento den akce neexistuje!
</font><P><A href=tm.php?heslo=".$heslo."&mesic=".$mesic."> Zpet</A>";
exit;

}
} 
?>
